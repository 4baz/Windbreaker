Ethereal rewritten using their own base kekw

WindBreaker, W Taker

public github: https://github.com/sinfail/Windbreaker   -  feel free to contribute :)


https://discord.gg/2fwhZVbREv

vesion 1.0.0

inject with injector of your choice, make sure WBreaker folder is in c drive

